pwd
./main > ./runout.txt
