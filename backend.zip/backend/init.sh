pwd
g++ -o main fly/test.cpp -O2 -std=c++11
rm /tmp/pipe.in /tmp/pipe.out
touch /tmp/pipe.in /tmp/pipe.out
